import React from "react";

function Detail(props) {
  return <p className="info">{props.info}</p>;
}

export default Detail;
