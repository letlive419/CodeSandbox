const pi = 3.1415692;

export default pi;
