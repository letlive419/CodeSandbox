import React from "react";
import Card from "./Card";
import emojipedias from "../emojipedia";

function fetchCard(emojipedia) {
  return (
    <Card
      key={emojipedia.id}
      emoji={emojipedia.emoji}
      name={emojipedia.name}
      meaning={emojipedia.meaning}
    />
  );
}
function App() {
  return (
    <div>
      <h1>
        <span>emojipedia</span>
      </h1>
      {emojipedias.map(fetchCard)}
    </div>
  );
}

export default App;
